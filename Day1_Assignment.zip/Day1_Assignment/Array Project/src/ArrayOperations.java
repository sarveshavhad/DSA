import java.util.Scanner;

public class ArrayOperations {

	public static void printArray(int size, int[]arr) {
		
		for(int i = 0; i < size; i++) {
			
			System.out.print(arr[i]+" ");
		}
		
	}
	
	public static int deleteFromPosition(int size, int []arr, int pos) {

		
		
		for(int i = pos; i < size-1; i++) {
			
			arr[i] = arr[i+1];
			
		}
		return size-1;
	}
	
	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Size of Array");
		int size = sc.nextInt();
		
		int []arr = new int[size];
 		
		for(int i = 0; i < size; i++) {
			System.out.println("Enter Element "+ (i+1) + " = ");
			arr[i] = sc.nextInt();
		}
		
		System.out.println("Printing Array");
		printArray(size, arr);
		
		
		System.out.println("Enter the posistion from you want to delete : ");
		int pos = sc.nextInt();
		
		int newSize = deleteFromPosition(size,arr,pos);
		
		System.out.println("Printing Array after Deletion");
		printArray(newSize, arr);
		System.out.println("New Size = " +deleteFromPosition(size,arr,pos));
		
		sc.close();
	}
	
}
