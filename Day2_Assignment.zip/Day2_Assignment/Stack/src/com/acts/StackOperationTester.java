package com.acts;

import java.util.Arrays;
import java.util.Scanner;

public class StackOperationTester {
	
	public static void reverseArray(int []arr, Stack s) {
		
		for(int i =0; i < arr.length; i++) {
			s.push(arr[i]);
		}
		
		
		try {
			for(int i = 0; i < arr.length; i++) {
				arr[i] = s.pop();	
				if(s.isEmpty()) {
					throw new StackEmptyExceptiopn("Stack is Empty");
				}
			}
				
		}catch(StackEmptyExceptiopn e) {
			
			System.out.println(e.getMessage());
		
		}
			
		
	}
	
	public static int[] resizeArray(int []arr, Stack s) {
	
		int[] newArray = new int[2 * arr.length];
		
		for(int i = 0; i < arr.length; i++) {
			newArray[i] = arr[i];
		}
	
		return newArray;
	}
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int size = 2;
		int [] nums = {11,45,74,47,70,35};
		
		System.out.println("Before Reversing - "+Arrays.toString(nums));
	
		Stack s = new ResizeArrayUsingStack(nums.length);
		reverseArray(nums, s);
		
		System.out.println("After Reversing - "+Arrays.toString(nums));

		
		
		
		Stack s1 = new ResizeArrayUsingStack(size);
		char ch;
		
		do {
			
			System.out.println("Enter Element in the array");
			int i = sc.nextInt();
			s1.push(i);
		
			sc.nextLine();
			System.out.println("Do you want to add y/n");
			ch = sc.nextLine().charAt(0);
				
		}while(ch != 'n');
		
		System.out.println(s1.toString());
		
		sc.close();

	}

}
