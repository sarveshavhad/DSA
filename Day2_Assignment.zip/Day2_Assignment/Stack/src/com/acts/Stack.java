package com.acts;

public interface Stack {

	void push(int element);
	int pop() throws StackEmptyExceptiopn;
	int peek();
	boolean isFull();
	boolean isEmpty();
	
	
}
