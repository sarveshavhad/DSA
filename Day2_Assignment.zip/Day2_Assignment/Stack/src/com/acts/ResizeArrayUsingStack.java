package com.acts;

import java.util.Arrays;

public class ResizeArrayUsingStack implements Stack{
	
	private int[] stackData;
	private int top;
	
	public  ResizeArrayUsingStack(int n) {
		
		this.stackData = new int[n];
		this.top = -1;
		
	}
	
	@Override
	public void push(int element) {
		
		if(isFull()) {
			int[] arr = new int[stackData.length * 2];
			
			for(int i=0;i<stackData.length;i++) {
				arr[i] = stackData[i];
			}
			stackData = arr;
		}
		
		top++;
		stackData[top] = element;
		
	}
	
	@Override
	public int peek() {
		return stackData[top];
	}
	
	@Override
	public int pop() throws StackEmptyExceptiopn {
		
		int result = stackData[top];
		--top;

		return result;	
	}
	
	@Override
	public boolean isEmpty() {
		
		if(top == -1) {
			return true;
		}
		
		return false;
		
	}
	
	@Override
	public boolean isFull() {
		
		if(top == (stackData.length - 1)) {
			return true;
		}
		
		return false;
		
	}
	
	@Override
	public String toString() {
		return "Elements in stack are :  "+Arrays.toString(stackData)+ " top = "+top;
	}

}
