package com.acts;

public class StckFullException extends Exception {

	public StckFullException(String str) {
		super(str);
	}
	
}
