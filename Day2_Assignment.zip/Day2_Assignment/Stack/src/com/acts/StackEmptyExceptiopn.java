package com.acts;

public class StackEmptyExceptiopn extends Exception{
	
	public StackEmptyExceptiopn(String str) {
		super(str);
	}

}
