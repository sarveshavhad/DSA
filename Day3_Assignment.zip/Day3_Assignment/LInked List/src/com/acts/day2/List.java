package com.acts.day2;

public interface List {

	void addAtFront(int element);
	void addAtRear(int elemnet);
	int deleteFirst();
	boolean isEmpty();
	void print();
	
	
}
