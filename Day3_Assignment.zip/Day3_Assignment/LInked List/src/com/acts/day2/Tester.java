package com.acts.day2;

import java.util.Arrays;

public class Tester {
	
	public static void testList() {
		
		List list = new SinglyLinkedList();
		list.addAtFront(10);
		list.addAtFront(5);
		list.addAtRear(15);
		list.addAtRear(20);
		
		list.print();
		
		
	}
	
	public static void reverseArrayUsingStack(int[] arr,Stack s) {
		
		for(int i=0;i<arr.length;++i) {
			s.push(arr[i]);
			
		}
		
		int i=0;
		while(!s.isEmpty()) {
			arr[i]= s.pop();
			i++;
		}
		
		
		
	}
	
	public static void testStack() {
		
		int[] arr = {1,2,3,4,5,6};
		System.out.println("Before Reversing - "+Arrays.toString(arr));
		
		Stack s = new StackUsingList();
		reverseArrayUsingStack(arr,s);
		System.out.println("After Reversing - "+Arrays.toString(arr));
	}
	
	public static void main(String[] args) {
	
		testList();
		
		testStack();
		
	}
	
}
