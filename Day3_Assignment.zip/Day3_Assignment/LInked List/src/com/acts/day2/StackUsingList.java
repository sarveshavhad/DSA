package com.acts.day2;

public class StackUsingList implements Stack {

	private List list;
	
	public StackUsingList() {
		 list = new SinglyLinkedList();
	}
	
	@Override
	public void push(int element) {
		list.addAtFront(element);

	}

	@Override
	public int pop() {
		int result = list.deleteFirst();
		return result;
	}

	@Override
	public int peek() {
		int result = list.deleteFirst();
		list.addAtFront(result);
		return result;
	}

	@Override
	public boolean isEmpty() {
		
		return list.isEmpty();
	}

	@Override
	public boolean isFull() {

		return false;
	}

}
