package com.acts.day2;

public interface Stack {

	void push(int element);
	int pop();
	int peek();
	boolean isEmpty();
	boolean isFull();
	
}
