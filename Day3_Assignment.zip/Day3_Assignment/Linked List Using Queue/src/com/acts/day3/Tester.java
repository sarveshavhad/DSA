package com.acts.day3;

import java.util.Arrays;

public class Tester {

	public static void testQueue() {
		
		int [] arr = {1,2,3,4,5,6};
		
		System.out.println("Array  - "+Arrays.toString(arr));
		
		Queue q = new QueueUsingList();
		
		q.enqueue(1);
		q.enqueue(2);
		q.enqueue(3);
		
		q.print();
		
		q.dequeue();
		q.print();
		
	}
	
	public static void main(String[] args) {
		
		testQueue();

	}

}
