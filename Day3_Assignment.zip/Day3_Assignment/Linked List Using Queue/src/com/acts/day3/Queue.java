package com.acts.day3;

public interface Queue {

	void enqueue(int element);
	int dequeue();
	void print();
	boolean isEmpty();
	
	
}
